#' @details This function needs to use id information from existing R 
#' resources.  See the references for more details.
