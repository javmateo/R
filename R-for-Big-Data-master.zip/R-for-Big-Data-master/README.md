# R-for-Big-Data

Teaching materials for handling large datasets in R. Currently the lecture notes are formatted using markdown with Tufte. In the near future (days), the tufte format will be removed.
